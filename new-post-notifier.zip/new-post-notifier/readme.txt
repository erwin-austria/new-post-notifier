=== New Post Notifier ===
Contributors: Portal Integrators
Tags: Post Notification, Post, Plugin
Donate link: www.portalintegrators.com
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 0.1
License: GPLv2 or later
License URI:  http://www.gnu.org/licenses/gpl-2.0.html

New Post Notifier is a plugin which will send automatic email when the post is published by a user to the selected administrator in the setting field.

== Description ==
New Post Notifier is a plugin which will send automatic email when the post is published by a user to the selected administrator in the setting field.

=Features=

Notify Admin via email when post is published.

Notify User via email when post is deleted or published

== Installation ==
This plugin is easy to install like other plug-ins of WordPress as you need to just follow the below mentioned steps:

upload New Post Notifier folder to wp-Content/plugins folder.

Activate the plugin from Dashboard / Plugins window.

Now Plugin is Activated, Go to the Setting section and select which admin will be sending the notification.

== Frequently Asked Questions ==
1.How to use ?

For More info use readme installation and usage notes.

== Screenshots ==
1. Setting Field

== Changelog ==
Stable 1.0 first release

== Upgrade Notice ==
Stable 1.0 first release